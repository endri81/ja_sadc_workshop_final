# ==============================================================================
# LAB 5.2: GWSM BASE WEIGHTS & CALIBRATION
# SADC Regional Training Workshop on Advanced Sampling Methods
# Day 5, Module 2 — The Generalized Weight Share Method & Calibration
#
# Data:    ghs-2024-person-v1.dta, ghs-2024-hhold-v1.dta (Zambara HHS)
# Source:  Falorsi, Righi & Ponzini (2025), WB Policy Research WP 11026
# Author:  Prof. Endri Raco | March 2026
# Version: 1.2 — Fixed: duplicate columns (psu/stratum/prov/geotype),
#                        personnr type, svydesign variable references
#
# SLIDE REFERENCES:
#   Exercise 1 (lines 35-75)   → Slides 4, 16  (Linking variables v1-v10)
#   Exercise 2 (lines 80-125)  → Slides 10, 13 (GWSM base weight)
#   Exercise 3 (lines 130-175) → Slides 19-23  (Sample union + alpha)
#   Exercise 4 (lines 180-250) → Slides 26, 30 (Calibration)
#   Exercise 5 (lines 255-320) → Slides 31, 36-37 (Diagnostics + comparison)
# ==============================================================================

# --- Setup -------------------------------------------------------------------
library(haven)
library(dplyr)
library(survey)

cat(strrep("=", 70), "\n")
cat("  LAB 5.2: GWSM BASE WEIGHTS & CALIBRATION\n")
cat("  Day 5, Module 2 — Generalized Weight Share Method\n")
cat("  Source: Falorsi et al. (2025), WB WP 11026, Sections 3-4\n")
cat(strrep("=", 70), "\n\n")

# ==============================================================================
# EXERCISE 1: PREPARE LINKING VARIABLES (Table 4.1)
# → Slide 4 (inclusion probabilities), Slide 16 (Table 4.1)
# ==============================================================================
cat("--- EXERCISE 1: Prepare Linking Variables ---\n\n")

person <- read_dta("ghs-2024-person-v1.dta")
hhold  <- read_dta("ghs-2024-hhold-v1.dta")

person <- person %>%
  mutate(
    panel_id = paste0(uqnr, "-", personnr),
    wave = 1L,
    is_head = (as.numeric(personnr) == 1)
  )

# CRITICAL: psu, stratum, prov, geotype exist in BOTH files.
# Only take house_wgt and hholdsz from hhold to avoid .x/.y duplicates.
df <- person %>%
  left_join(
    hhold %>% select(uqnr, house_wgt, hholdsz),
    by = "uqnr"
  ) %>%
  group_by(uqnr) %>%
  mutate(n_in_hh = n()) %>%
  ungroup()

# Verify key columns exist
stopifnot("psu" %in% names(df))
stopifnot("stratum" %in% names(df))
stopifnot("house_wgt" %in% names(df))

cat("Merged dataset:", nrow(df), "persons\n")
cat("Columns psu/stratum/prov/geotype confirmed present\n\n")

# Simulate split-offs (same as Lab 5.1)
set.seed(2026)
df <- df %>%
  filter(!is.na(house_wgt) & house_wgt > 0) %>%
  mutate(
    is_mover = (!is_head & n_in_hh >= 3 & runif(n()) < 0.30),
    uqnr_t = ifelse(is_mover, paste0(uqnr, "_split"), as.character(uqnr)),
    wave = 2L
  )

# --- Build Table 4.1 variables ---
df$v2  <- "t_star"
df$v4  <- 1 / df$house_wgt       # inclusion probability
df$v6  <- 1L                      # population membership
df$v7  <- ifelse(!df$is_mover, 2L, 1L)
df$v9  <- 1L
df$v10 <- 1L

df <- df %>%
  group_by(uqnr_t) %>%
  mutate(v8 = max(v7)) %>%
  ungroup()

cat("Linking variables created for", nrow(df), "persons\n")
cat("Distribution of v7 (individual multiplicity):\n")
print(table(v7 = df$v7))
cat("Distribution of v8 (HH multiplicity):\n")
print(table(v8 = df$v8))
cat("\n")

# ==============================================================================
# EXERCISE 2: COMPUTE GWSM BASE WEIGHTS
# → Slide 10 (GWSM formula), Slide 13 (code)
# Concept: Falorsi et al. (2025), Eq. (3.7)-(3.8), Table 4.1 formula
# ==============================================================================
cat("--- EXERCISE 2: GWSM Base Weights ---\n\n")

gwsm_weights <- df %>%
  group_by(uqnr_t) %>%
  summarise(
    L_k = sum(v6),
    sum_inv_pi = sum(v10 / v4),
    v8 = first(v8),
    psu = first(psu),
    stratum = first(stratum),
    prov = first(prov),
    geotype = first(geotype),
    n_members = n(),
    .groups = "drop"
  ) %>%
  mutate(
    d_gwsm = (1 / L_k) * sum_inv_pi,
    w_base = (1 / v8) * (1 / L_k) * sum_inv_pi
  )

cat("GWSM weight (before multiplicity):\n")
print(summary(gwsm_weights$d_gwsm))
cat("\nBase weight (after multiplicity):\n")
print(summary(gwsm_weights$w_base))
cat("\nCV of base weights:",
    round(sd(gwsm_weights$w_base) / mean(gwsm_weights$w_base), 3), "\n")
cat("Sum of base weights (pop estimate):",
    format(sum(gwsm_weights$w_base * gwsm_weights$n_members),
           big.mark = ","), "\n\n")

# ==============================================================================
# EXERCISE 3: SAMPLE UNION & ALPHA
# → Slide 19 (sample union), Slide 20 (alpha), Slide 23 (code)
# Concept: Falorsi et al. (2025), Eq. (3.13)-(3.15)
# ==============================================================================
cat("--- EXERCISE 3: Sample Union & Alpha ---\n\n")

set.seed(42)
gwsm_weights <- gwsm_weights %>%
  mutate(
    source = sample(c("old_panel", "refresh"),
                    n(), replace = TRUE, prob = c(0.5, 0.5)),
    F_k = ifelse(source == "old_panel", 1L,
                 rbinom(n(), 1, 0.85))
  )

m_old <- sum(gwsm_weights$source == "old_panel")
m_ref <- sum(gwsm_weights$source == "refresh")
alpha <- m_old / (m_old + m_ref)

cat("Old panel HHs:", m_old, "\n")
cat("Refresh HHs:", m_ref, "\n")
cat("Alpha:", round(alpha, 4), "\n")
cat("Multiplicity factor (1/alpha):", round(1/alpha, 4), "\n\n")

gwsm_weights <- gwsm_weights %>%
  mutate(
    d_union = case_when(
      source == "old_panel" ~ alpha * d_gwsm,
      source == "refresh" & F_k == 1 ~ (1 - alpha) * d_gwsm,
      source == "refresh" & F_k == 0 ~ d_gwsm,
      TRUE ~ NA_real_
    )
  )

cat("Sample-union weight distribution:\n")
print(summary(gwsm_weights$d_union))
cat("\n")

# ==============================================================================
# EXERCISE 4: CALIBRATION TO KNOWN POPULATION TOTALS
# → Slide 26 (calibration math), Slide 30 (code)
# Concept: Deville & Sarndal (1992), Falorsi et al. (2025), Eq. (3.16)-(3.17)
# ==============================================================================
cat("--- EXERCISE 4: Calibration ---\n\n")

# Merge weights back to person-level data
df_cal <- df %>%
  left_join(
    gwsm_weights %>% select(uqnr_t, d_union, d_gwsm, w_base, source, F_k),
    by = "uqnr_t"
  ) %>%
  filter(!is.na(d_union) & d_union > 0)

# Create calibration auxiliaries
df_cal <- df_cal %>%
  mutate(
    male   = as.numeric(Sex == 1),
    female = as.numeric(Sex == 2),
    urban  = as.numeric(geotype == 1),
    rural  = as.numeric(geotype != 1)
  )

# Verify design variables exist before svydesign
cat("Checking design variables...\n")
cat("  psu present:", "psu" %in% names(df_cal), "\n")
cat("  stratum present:", "stratum" %in% names(df_cal), "\n")
cat("  d_union present:", "d_union" %in% names(df_cal), "\n\n")

# Set up survey design
des_base <- svydesign(
  id = ~psu,
  strata = ~stratum,
  weights = ~d_union,
  data = df_cal,
  nest = TRUE
)

# Known population totals
pop_totals <- c(
  male  = 29500000,
  female = 31200000
)

# Calibrate
calibrated <- FALSE
tryCatch({
  des_cal <- calibrate(
    des_base,
    formula = ~ male + female,
    population = pop_totals,
    calfun = "raking",
    bounds = c(0.2, 5.0),
    maxit = 100
  )
  cat("Calibration CONVERGED\n")
  cat("Calibrated weight distribution:\n")
  print(summary(weights(des_cal)))

  g_factor <- weights(des_cal) / df_cal$d_union
  cat("\nG-factor (calibration adjustment):\n")
  cat("  Min:", round(min(g_factor, na.rm = TRUE), 3), "\n")
  cat("  Max:", round(max(g_factor, na.rm = TRUE), 3), "\n")
  cat("  Mean:", round(mean(g_factor, na.rm = TRUE), 3), "\n\n")

  calibrated <- TRUE
}, error = function(e) {
  cat("Calibration FAILED:", e$message, "\n")
  cat("Using base weights for comparisons\n\n")
})

if (!calibrated) {
  des_cal <- des_base
}

# ==============================================================================
# EXERCISE 5: DIAGNOSTICS & COMPARISON
# → Slide 31 (empirical results), Slides 36-37 (code + verification)
# ==============================================================================
cat("--- EXERCISE 5: Diagnostics & Comparison ---\n\n")

# Simulate outcome variables
df_cal$poor     <- rbinom(nrow(df_cal), 1, prob = 0.20)
df_cal$employed <- rbinom(nrow(df_cal), 1, prob = 0.55)

# Rebuild designs with outcome variables
des_base <- svydesign(
  id = ~psu, strata = ~stratum,
  weights = ~d_union, data = df_cal, nest = TRUE)

if (calibrated) {
  des_cal <- calibrate(
    des_base,
    formula = ~ male + female,
    population = pop_totals,
    calfun = "raking",
    bounds = c(0.2, 5.0),
    maxit = 100
  )
}

# Base-weighted estimates
cat("BASE-WEIGHTED ESTIMATES:\n")
pov_base <- svymean(~poor, des_base, na.rm = TRUE)
emp_base <- svymean(~employed, des_base, na.rm = TRUE)
cat("  Poverty rate:", round(coef(pov_base)[1] * 100, 1), "%\n")
cat("  Employment rate:", round(coef(emp_base)[1] * 100, 1), "%\n\n")

# Calibrated estimates
if (calibrated) {
  cat("CALIBRATED ESTIMATES:\n")
  pov_cal <- svymean(~poor, des_cal, na.rm = TRUE)
  emp_cal <- svymean(~employed, des_cal, na.rm = TRUE)
  cat("  Poverty rate:", round(coef(pov_cal)[1] * 100, 1), "%\n")
  cat("  Employment rate:", round(coef(emp_cal)[1] * 100, 1), "%\n\n")
}

# Weight sum comparison
cat("POPULATION TOTALS:\n")
cat("  Base weight sum:", format(sum(df_cal$d_union), big.mark = ","), "\n")
if (calibrated) {
  cat("  Calibrated sum:", format(sum(weights(des_cal)), big.mark = ","), "\n")
}
cat("  Target (census):", format(sum(pop_totals), big.mark = ","), "\n\n")

# ==============================================================================
# VERIFICATION TABLE → Slide 37
# ==============================================================================
cat(strrep("=", 70), "\n")
cat("  VERIFICATION TABLE — LAB 5.2 RESULTS\n")
cat(strrep("=", 70), "\n")
cat(sprintf("  %-40s %12s\n", "Metric", "Value"))
cat(strrep("-", 54), "\n")
cat(sprintf("  %-40s %12d\n", "Persons in analysis", nrow(df_cal)))
cat(sprintf("  %-40s %12d\n", "Follow-up HHs", nrow(gwsm_weights)))
cat(sprintf("  %-40s %12.1f\n", "GWSM weight mean", mean(gwsm_weights$d_gwsm)))
cat(sprintf("  %-40s %12.3f\n", "GWSM weight CV",
    sd(gwsm_weights$d_gwsm) / mean(gwsm_weights$d_gwsm)))
cat(sprintf("  %-40s %12.4f\n", "Alpha", alpha))
cat(sprintf("  %-40s %12.1f\n", "Base weight mean", mean(gwsm_weights$w_base)))
cat(sprintf("  %-40s %12s\n", "Base weight sum",
    format(sum(df_cal$d_union), big.mark = ",")))
cat(sprintf("  %-40s %11.1f%%\n", "Base-wt poverty",
    coef(pov_base)[1] * 100))
cat(sprintf("  %-40s %11.1f%%\n", "Base-wt employment",
    coef(emp_base)[1] * 100))
if (calibrated) {
  g_factor <- weights(des_cal) / df_cal$d_union
  cat(sprintf("  %-40s %11.1f%%\n", "Calibrated poverty",
      coef(pov_cal)[1] * 100))
  cat(sprintf("  %-40s %11.1f%%\n", "Calibrated employment",
      coef(emp_cal)[1] * 100))
  cat(sprintf("  %-40s %10.3f-%.3f\n", "G-factor range",
      min(g_factor, na.rm = TRUE), max(g_factor, na.rm = TRUE)))
}
cat(strrep("=", 54), "\n")
cat("  End of Lab 5.2 — Proceed to Module 3\n\n")
