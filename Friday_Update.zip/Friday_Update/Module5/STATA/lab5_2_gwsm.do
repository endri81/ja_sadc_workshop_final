* ==============================================================================
* LAB 5.2: GWSM BASE WEIGHTS & CALIBRATION
* SADC Regional Training Workshop on Advanced Sampling Methods
* Day 5, Module 2 — The Generalized Weight Share Method & Calibration
*
* Data:    ghs-2024-person-v1.dta, ghs-2024-hhold-v1.dta (Zambara HHS)
* Source:  Falorsi, Righi & Ponzini (2025), WB Policy Research WP 11026
* Author:  Prof. Endri Raco | March 2026
* Version: 1.1 — Patched: string types, distinct→native, personnr type
*
* SLIDE REFERENCES:
*   Exercise 1 (lines 35-85)   → Slides 4, 16
*   Exercise 2 (lines 90-135)  → Slides 10, 13
*   Exercise 3 (lines 140-185) → Slides 19-23
*   Exercise 4 (lines 190-260) → Slides 26, 30
*   Exercise 5 (lines 265-340) → Slides 31, 36-37
* ==============================================================================

clear all
set more off
set seed 2026

display as text _n _dup(70) "="
display as text "  LAB 5.2: GWSM BASE WEIGHTS & CALIBRATION"
display as text "  Day 5, Module 2 — Generalized Weight Share Method"
display as text "  Source: Falorsi et al. (2025), WB WP 11026"
display as text _dup(70) "=" _n

* ==============================================================================
* EXERCISE 1: PREPARE LINKING VARIABLES (Table 4.1)
* → Slide 4, Slide 16
* ==============================================================================
display as text "--- EXERCISE 1: Prepare Linking Variables ---" _n

use "ghs-2024-person-v1.dta", clear

* --- Robust panel_id & is_head (handles string or numeric personnr) ---
capture confirm string variable personnr
if _rc == 0 {
    gen panel_id = uqnr + "-" + personnr
    destring personnr, gen(personnr_num) force
    gen is_head = (personnr_num == 1)
    drop personnr_num
}
else {
    gen panel_id = uqnr + "-" + string(personnr)
    gen is_head = (personnr == 1)
}

gen wave = 1

tempfile person_temp
save `person_temp', replace

use "ghs-2024-hhold-v1.dta", clear
keep uqnr psu stratum house_wgt hholdsz prov geotype
tempfile hhold_temp
save `hhold_temp', replace

use `person_temp', clear
merge m:1 uqnr using `hhold_temp'
keep if _merge == 3
drop _merge

* Keep valid weights
keep if house_wgt > 0 & !missing(house_wgt)

bysort uqnr: gen n_in_hh = _N

* Simulate split-offs (same as Lab 5.1)
gen is_mover = (!is_head & n_in_hh >= 3 & runiform() < 0.30)
gen uqnr_t = uqnr
replace uqnr_t = uqnr + "_split" if is_mover
replace wave = 2

* --- Table 4.1 variables ---
gen v2 = "t_star"
gen v4 = 1 / house_wgt
gen v6 = 1
gen v7 = cond(!is_mover, 2, 1)
gen v9 = 1
gen v10 = 1

bysort uqnr_t: egen v8 = max(v7)

display as text "Linking variables created for " _N " persons"
tab v7, m
tab v8, m

* ==============================================================================
* EXERCISE 2: COMPUTE GWSM BASE WEIGHTS
* → Slide 10, Slide 13
* ==============================================================================
display as text _n "--- EXERCISE 2: GWSM Base Weights ---" _n

bysort uqnr_t: egen L_k = total(v6)

gen inv_pi_resp = v10 / v4
bysort uqnr_t: egen sum_inv_pi = total(inv_pi_resp)

* GWSM weight (before multiplicity)
gen d_gwsm = (1 / L_k) * sum_inv_pi

* Base weight with multiplicity
gen w_base = (1 / v8) * (1 / L_k) * sum_inv_pi

display as text "GWSM weight (before multiplicity):"
summarize d_gwsm, detail

display as text "Base weight (after multiplicity):"
summarize w_base, detail

summarize w_base
local cv_base = r(sd) / r(mean)
display as text "CV of base weights: " %6.3f `cv_base'
display as text "Sum of base weights: " %15.0fc r(sum) _n

* ==============================================================================
* EXERCISE 3: SAMPLE UNION & ALPHA
* → Slides 19-23
* ==============================================================================
display as text "--- EXERCISE 3: Sample Union & Alpha ---" _n

set seed 42
gen rand_source = runiform()
bysort uqnr_t: replace rand_source = rand_source[1]

gen source = cond(rand_source < 0.5, "old_panel", "refresh")

gen F_k = 1
replace F_k = (runiform() < 0.85) if source == "refresh"
bysort uqnr_t: replace F_k = F_k[1]

* Compute alpha (native — no SSC)
preserve
    bysort uqnr_t: keep if _n == 1
    count if source == "old_panel"
    local m_old = r(N)
    count if source == "refresh"
    local m_ref = r(N)
restore

local alpha = `m_old' / (`m_old' + `m_ref')
display as text "Old panel HHs: `m_old'"
display as text "Refresh HHs: `m_ref'"
display as text "Alpha: " %6.4f `alpha'
display as text "Multiplicity (1/alpha): " %6.4f (1/`alpha') _n

* Sample-union weight
gen d_union = .
replace d_union = `alpha' * d_gwsm if source == "old_panel"
replace d_union = (1-`alpha') * d_gwsm if source == "refresh" & F_k == 1
replace d_union = d_gwsm if source == "refresh" & F_k == 0

display as text "Sample-union weight distribution:"
summarize d_union, detail

* ==============================================================================
* EXERCISE 4: CALIBRATION
* → Slide 26, Slide 30
* ==============================================================================
display as text _n "--- EXERCISE 4: Calibration ---" _n

* Calibration auxiliaries
gen male   = (Sex == 1)
gen female = (Sex == 2)
gen urban  = (geotype == 1)
gen rural  = (geotype != 1)

* Simulated outcome variables
gen poor = (runiform() < 0.20)
gen employed = (runiform() < 0.55)

* Set survey design
svyset psu [pw=d_union], strata(stratum)

display as text "PRE-CALIBRATION ESTIMATES:"
svy: proportion poor
svy: proportion employed

* Post-stratification by sex (proxy for calibration)
quietly svy: total male
local est_male = _b[male]
quietly svy: total female
local est_female = _b[female]

local g_male = 29500000 / `est_male'
local g_female = 31200000 / `est_female'

display as text "G-factor male: " %6.3f `g_male'
display as text "G-factor female: " %6.3f `g_female'

gen w_cal = d_union * cond(male == 1, `g_male', `g_female')

gen g_factor = w_cal / d_union
summarize g_factor, detail
display as text "G-factor range: " %6.3f r(min) " to " %6.3f r(max)

* ==============================================================================
* EXERCISE 5: DIAGNOSTICS & COMPARISON
* → Slides 31, 36-37
* ==============================================================================
display as text _n "--- EXERCISE 5: Diagnostics & Comparison ---" _n

svyset psu [pw=w_cal], strata(stratum)

display as text "POST-CALIBRATION ESTIMATES:"
svy: proportion poor
svy: proportion employed

summarize d_union, meanonly
display as text "Base weight sum: " %15.0fc r(sum)

summarize w_cal, meanonly
display as text "Calibrated sum: " %15.0fc r(sum)

display as text "Target: " %15.0fc 60700000 _n

* ==============================================================================
* VERIFICATION TABLE → Slide 37
* ==============================================================================
display as text _dup(70) "="
display as text "  VERIFICATION TABLE — LAB 5.2 RESULTS"
display as text _dup(70) "="
display as text "  Metric                                    Value"
display as text _dup(54) "-"
display as text "  Persons in analysis                  " %10.0fc _N

summarize d_gwsm, meanonly
display as text "  GWSM weight mean                     " %10.1f r(mean)

summarize w_base, meanonly
display as text "  Base weight mean                     " %10.1f r(mean)

display as text "  Alpha                                " %10.4f `alpha'

summarize d_union
display as text "  Union weight sum                     " %12.0fc r(sum)

summarize w_cal
display as text "  Calibrated weight sum                " %12.0fc r(sum)

summarize g_factor
display as text "  G-factor min                         " %10.3f r(min)
display as text "  G-factor max                         " %10.3f r(max)

display as text _dup(54) "="
display as text "  End of Lab 5.2 — Proceed to Module 3" _n
