* ==============================================================================
* LAB 5.1: HOUSEHOLD CONTINUITY & LONGITUDINAL POPULATION DEFINITIONS
* SADC Regional Training Workshop on Advanced Sampling Methods
* Day 5, Module 1 — Defining Longitudinal Populations & Continuity Rules
*
* Data:    ghs-2024-person-v1.dta, ghs-2024-hhold-v1.dta (Zambara HHS)
* Source:  Falorsi, Righi & Ponzini (2025), WB Policy Research WP 11026
* Author:  Prof. Endri Raco | March 2026
* Version: 1.1 — Patched: string types, distinct→native, personnr type
*
* SLIDE REFERENCES:
*   Exercise 1 (lines 30-80)   → Slides 6, 35
*   Exercise 2 (lines 85-130)  → Slides 13, 14
*   Exercise 3 (lines 135-195) → Slides 22-24, 36
*   Exercise 4 (lines 200-260) → Slides 25-26, 37
*   Exercise 5 (lines 265-345) → Slides 28-32, 38
* ==============================================================================

clear all
set more off
set seed 2026

display as text _n _dup(70) "="
display as text "  LAB 5.1: HOUSEHOLD CONTINUITY SIMULATION"
display as text "  Day 5, Module 1 — Longitudinal Population Definitions"
display as text "  Source: Falorsi, Righi & Ponzini (2025), WB WP 11026"
display as text _dup(70) "=" _n

* ==============================================================================
* EXERCISE 1: MERGE PERSON x HOUSEHOLD FILES & CREATE PANEL IDS
* → Slide 6 (code), Slide 35 (lab walkthrough)
* ==============================================================================
display as text "--- EXERCISE 1: Merge Person x Household + Panel IDs ---" _n

use "ghs-2024-person-v1.dta", clear
local N_person = _N
display as text "Person file: `N_person' observations"

* --- Robust panel_id creation ---
* personnr may be string or numeric depending on the data version
capture confirm string variable personnr
if _rc == 0 {
    * personnr is string
    gen panel_id = uqnr + "-" + personnr
    destring personnr, gen(personnr_num) force
    gen is_head = (personnr_num == 1)
    drop personnr_num
}
else {
    * personnr is numeric
    gen panel_id = uqnr + "-" + string(personnr)
    gen is_head = (personnr == 1)
}

gen wave = 1

tempfile person_temp
save `person_temp', replace

* Load household file
use "ghs-2024-hhold-v1.dta", clear
local N_hhold = _N
display as text "Household file: `N_hhold' observations"

keep uqnr psu stratum house_wgt hholdsz prov geotype
tempfile hhold_temp
save `hhold_temp', replace

* Merge
use `person_temp', clear
merge m:1 uqnr using `hhold_temp'
tab _merge
keep if _merge == 3
drop _merge

bysort uqnr: gen n_in_hh = _N

display as text _n "Merged dataset: " _N " person-records"

* Count unique HHs (native — no SSC needed)
preserve
    bysort uqnr: keep if _n == 1
    local n_hh_unique = _N
restore
display as text "Unique households: `n_hh_unique'"
display as text "Unique persons: " _N
summarize n_in_hh, detail
display as text ""

* ==============================================================================
* EXERCISE 2: SIMULATE POPULATION DEFINITIONS
* → Slide 13, 14
* ==============================================================================
display as text "--- EXERCISE 2: Population Definitions ---" _n

local N_baseline = _N

gen died = (runiform() < 0.03)
gen emigrated = (runiform() < 0.02)
gen alive_t = (!died & !emigrated)

count if alive_t
local N_intersect = r(N)

local n_births = int(`N_baseline' * 0.04)
local n_immigrants = int(`N_baseline' * 0.015)
local N_hybrid = `N_intersect' + `n_births'
local N_union = `N_baseline' + `n_births' + `n_immigrants'
local N_Ut = `N_intersect' + `n_births' + `n_immigrants'
local cov_hybrid = 100 * `N_hybrid' / `N_Ut'
local cov_inter  = 100 * `N_intersect' / `N_Ut'

display as text "Baseline N (t*):          " %10.0fc `N_baseline'
display as text "Intersection:             " %10.0fc `N_intersect'
display as text "Hybrid (intersect+births):" %10.0fc `N_hybrid'
display as text "Union (all ever-present): " %10.0fc `N_union'
display as text "Cross-sectional U_t:      " %10.0fc `N_Ut'
display as text "Hybrid coverage of U_t:   " %9.1f `cov_hybrid' "%"
display as text "Intersection coverage:    " %9.1f `cov_inter' "%" _n

* ==============================================================================
* EXERCISE 3: SIMULATE HOUSEHOLD SPLITS & COMPUTE L_k
* → Slides 22-24, 36
* ==============================================================================
display as text "--- EXERCISE 3: Household Splits & Link Counts ---" _n

keep if alive_t

gen is_mover = (!is_head & n_in_hh >= 3 & runiform() < 0.30)

* Follow-up HH ID (uqnr is string in GHS 2024)
gen uqnr_t = uqnr
replace uqnr_t = uqnr + "_split" if is_mover

replace wave = 2

count if is_mover
local n_movers = r(N)
display as text "Simulated movers: `n_movers'"

preserve
    bysort uqnr: keep if _n == 1
    local n_hh_base = _N
restore
display as text "Baseline HHs: `n_hh_base'"

preserve
    bysort uqnr_t: keep if _n == 1
    local n_hh_followup = _N
restore
display as text "Follow-up HHs: `n_hh_followup'"

preserve
    keep if is_mover
    bysort uqnr_t: keep if _n == 1
    local n_splitoff = _N
restore
display as text "Split-off HHs created: `n_splitoff'" _n

* L_k: potential links
bysort uqnr_t: egen L_k = count(panel_id)

display as text "Distribution of L_k:"
summarize L_k, detail

* Per-origin links
bysort uqnr_t uqnr: gen L_kl = _N

egen tag_origin = tag(uqnr_t uqnr)
bysort uqnr_t: egen n_origins = total(tag_origin)

preserve
    bysort uqnr_t: keep if _n == 1
    count if n_origins == 1
    display as text "Follow-up HHs with 1 origin: " r(N)
    count if n_origins >= 2
    display as text "Follow-up HHs with 2+ origins: " r(N)
restore
display as text ""

drop tag_origin

* ==============================================================================
* EXERCISE 4: ONE-TO-ONE vs. MANY-TO-MANY
* → Slides 25-26, 37
* ==============================================================================
display as text "--- EXERCISE 4: One-to-One vs. Many-to-Many ---" _n

* One-to-one: follow head's HH
preserve
    keep if is_head
    bysort uqnr_t: keep if _n == 1
    local n_hh_1to1 = _N
    keep uqnr_t
    tempfile head_hhs
    save `head_hhs', replace
restore

* Persons in head's HHs
preserve
    merge m:1 uqnr_t using `head_hhs', keep(match) nogen
    local persons_1to1 = _N
restore

local persons_m2m = _N
local n_hh_m2m = `n_hh_followup'
local persons_lost = `persons_m2m' - `persons_1to1'
local pct_loss = 100 * `persons_lost' / `persons_m2m'

display as text "ONE-TO-ONE RULE:"
display as text "  Continuation HHs: `n_hh_1to1'"
display as text "  Persons covered:  `persons_1to1'" _n

display as text "MANY-TO-MANY RULE:"
display as text "  Continuation HHs: `n_hh_m2m'"
display as text "  Persons covered:  `persons_m2m'" _n

display as text "COVERAGE COMPARISON:"
display as text "  Persons lost:     `persons_lost'"
display as text "  Coverage loss:    " %5.1f `pct_loss' "%" _n

* ==============================================================================
* EXERCISE 5: MULTIPLICITY FACTOR & TRANSITIONS
* → Slides 28-32, 38
* ==============================================================================
display as text "--- EXERCISE 5: Multiplicity Factor & Transitions ---" _n

bysort uqnr_t: egen has_original = max(!is_mover)
gen mult_factor = cond(has_original, 2, 1)

display as text "Multiplicity factor distribution:"
tab mult_factor

display as text "Mean L_k by multiplicity factor:"
tabstat L_k, by(mult_factor) stat(mean sd n)

* Poverty transition
gen poor_tstar = (runiform() < 0.20)
gen poor_t = 0
replace poor_t = (runiform() < 0.70) if poor_tstar == 1
replace poor_t = (runiform() < 0.05) if poor_tstar == 0

display as text _n "Poverty Transition Matrix (simulated):"
tab poor_tstar poor_t, row cell

summarize poor_tstar, meanonly
local pov_tstar = r(mean)
summarize poor_t, meanonly
local pov_t = r(mean)
local net_change = (`pov_t' - `pov_tstar') * 100

display as text _n "Poverty rate at t*: " %5.1f `=`pov_tstar'*100' "%"
display as text "Poverty rate at t:  " %5.1f `=`pov_t'*100' "%"
display as text "Net change:         " %5.1f `net_change' " pp" _n

* ==============================================================================
* VERIFICATION TABLE → Slide 38
* ==============================================================================
display as text _dup(70) "="
display as text "  VERIFICATION TABLE — LAB 5.1 RESULTS"
display as text _dup(70) "="
display as text "  Metric                                 Value"
display as text _dup(54) "-"
display as text "  Persons at baseline              " %10.0fc `N_baseline'
display as text "  HHs at baseline                  " %10.0fc `n_hh_base'
display as text "  Persons alive at t               " %10.0fc `N_intersect'
display as text "  Hybrid pop. size                 " %10.0fc `N_hybrid'
display as text "  Hybrid coverage of U_t           " %9.1f `cov_hybrid' "%"
display as text "  Simulated movers                 " %10.0fc `n_movers'
display as text "  Split-off HHs                    " %10.0fc `n_splitoff'
display as text "  Follow-up HHs (many-to-many)     " %10.0fc `n_hh_m2m'
display as text "  Continuation HHs (one-to-one)    " %10.0fc `n_hh_1to1'
display as text "  Persons lost (one-to-one)        " %10.0fc `persons_lost'
display as text "  Coverage loss                    " %9.1f `pct_loss' "%"
display as text "  Poverty at t*                    " %9.1f `=`pov_tstar'*100' "%"
display as text "  Poverty at t                     " %9.1f `=`pov_t'*100' "%"
display as text _dup(54) "="
display as text "  End of Lab 5.1 — Proceed to Module 2 (GWSM Weights)" _n
