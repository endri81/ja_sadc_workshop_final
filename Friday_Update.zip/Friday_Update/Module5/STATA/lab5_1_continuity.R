# ==============================================================================
# LAB 5.1: HOUSEHOLD CONTINUITY & LONGITUDINAL POPULATION DEFINITIONS
# SADC Regional Training Workshop on Advanced Sampling Methods
# Day 5, Module 1 — Defining Longitudinal Populations & Continuity Rules
#
# Data:    ghs-2024-person-v1.dta, ghs-2024-hhold-v1.dta (Zambara HHS)
# Source:  Falorsi, Righi & Ponzini (2025), WB Policy Research WP 11026
# Author:  Prof. Endri Raco | March 2026
#
# SLIDE REFERENCES:
#   Exercise 1 (lines 30-55)  → Slides 6, 35  (Merge + panel ID)
#   Exercise 2 (lines 60-95)  → Slides 13, 14 (Population sizes)
#   Exercise 3 (lines 100-150) → Slides 22-24, 36 (Household splits + L_k)
#   Exercise 4 (lines 155-200) → Slides 25-26, 37 (1-to-1 vs M-to-M)
#   Exercise 5 (lines 205-260) → Slides 28-32, 38 (Multiplicity + transitions)
# ==============================================================================

# --- Setup -------------------------------------------------------------------
library(haven)
library(dplyr)
library(tidyr)

cat(strrep("=", 70), "\n")
cat("  LAB 5.1: HOUSEHOLD CONTINUITY SIMULATION\n")
cat("  Day 5, Module 1 — Longitudinal Population Definitions\n")
cat("  Source: Falorsi, Righi & Ponzini (2025), WB WP 11026\n")
cat(strrep("=", 70), "\n\n")

# ==============================================================================
# EXERCISE 1: MERGE PERSON x HOUSEHOLD FILES & CREATE PANEL IDS
# → Slide 6 (code), Slide 35 (lab walkthrough)
# ==============================================================================
cat("--- EXERCISE 1: Merge Person x Household + Panel IDs ---\n\n")

# Load data
person <- read_dta("ghs-2024-person-v1.dta")
hhold  <- read_dta("ghs-2024-hhold-v1.dta")

cat("Person file:", nrow(person), "observations,", ncol(person), "variables\n")
cat("Household file:", nrow(hhold), "observations,", ncol(hhold), "variables\n\n")

# Create stable panel identifier (unique person across waves)
person <- person %>%
  mutate(
    panel_id = paste0(uqnr, "-", personnr),
    wave     = 1L,
    is_head  = (as.numeric(personnr) == 1)
  )

# Merge household-level attributes onto person records
df <- person %>%
  left_join(
    hhold %>% select(uqnr, house_wgt, hholdsz),
    by = "uqnr"
  ) %>%
  group_by(uqnr) %>%
  mutate(n_in_hh = n()) %>%
  ungroup()

cat("Merged dataset:", nrow(df), "person-records\n")
cat("Unique households:", n_distinct(df$uqnr), "\n")
cat("Unique persons:", n_distinct(df$panel_id), "\n")
cat("Household size distribution:\n")
print(summary(df$n_in_hh))
cat("\n")

# ==============================================================================
# EXERCISE 2: SIMULATE POPULATION DEFINITIONS (INTERSECTION / UNION / HYBRID)
# → Slide 13 (numerical example), Slide 14 (code)
# Concept: Falorsi et al. (2025), Section 2.1
# ==============================================================================
cat("--- EXERCISE 2: Population Definitions ---\n\n")

set.seed(2026)

# Simulate demographic events between t* and t
df <- df %>%
  mutate(
    died      = runif(n()) < 0.03,    # 3% mortality
    emigrated = runif(n()) < 0.02,    # 2% emigration
    alive_t   = !died & !emigrated    # Still in country at t
  )

# --- Intersection population: only those alive at both t* and t ---
N_baseline    <- nrow(df)
N_intersect   <- sum(df$alive_t)

# --- Simulate new entrants ---
n_births      <- floor(N_baseline * 0.04)    # 4% births
n_immigrants  <- floor(N_baseline * 0.015)   # 1.5% immigration

# --- Hybrid: intersection + new HH members (births into tracked HHs) ---
N_hybrid      <- N_intersect + n_births

# --- Union: everyone ---
N_union       <- N_baseline + n_births + n_immigrants  # includes deaths (counted at t*)

# --- Current cross-sectional population U_t ---
N_Ut          <- N_intersect + n_births + n_immigrants

cat(sprintf("%-40s %10d\n", "Baseline N (t*):", N_baseline))
cat(sprintf("%-40s %10d\n", "Intersection (alive at both):", N_intersect))
cat(sprintf("%-40s %10d\n", "Hybrid (intersect + births):", N_hybrid))
cat(sprintf("%-40s %10d\n", "Union (all ever-present):", N_union))
cat(sprintf("%-40s %10d\n", "Cross-sectional U_t:", N_Ut))
cat(sprintf("%-40s %9.1f%%\n", "Hybrid coverage of U_t:",
            100 * N_hybrid / N_Ut))
cat(sprintf("%-40s %9.1f%%\n", "Intersection coverage of U_t:",
            100 * N_intersect / N_Ut))
cat("\n")

# ==============================================================================
# EXERCISE 3: SIMULATE HOUSEHOLD SPLITS & COMPUTE LINK COUNTS L_k
# → Slide 22 (diagram), Slide 23 (link matrix), Slide 24 (code), Slide 36
# Concept: Falorsi et al. (2025), Equation (2.1), (2.9), Schema 2.1
# ==============================================================================
cat("--- EXERCISE 3: Household Splits & Link Counts ---\n\n")

# Keep only those alive at t for the follow-up simulation
df_alive <- df %>% filter(alive_t)

# Simulate split-offs: 30% of non-head members in HHs with 3+ members
# move to form new households
df_followup <- df_alive %>%
  mutate(
    is_mover = (!is_head & n_in_hh >= 3 & runif(n()) < 0.30),
    # Movers get a new household ID (simulating split-off formation)
    uqnr_t = ifelse(is_mover,
                     paste0(uqnr, "_split"),
                     as.character(uqnr)),
    wave = 2L
  )

n_movers      <- sum(df_followup$is_mover)
n_splitoff_hh <- n_distinct(df_followup$uqnr_t[df_followup$is_mover])
n_hh_followup <- n_distinct(df_followup$uqnr_t)

cat("Simulated movers (split-off members):", n_movers, "\n")
cat("New split-off households created:", n_splitoff_hh, "\n")
cat("Original households (baseline):", n_distinct(df_alive$uqnr), "\n")
cat("Follow-up households (total):", n_hh_followup, "\n\n")

# --- Compute L_k: potential links for each follow-up household ---
# L_k = number of members in HH k at time t who belonged to U_{t*}
# In our simulation, all surviving persons were in U_{t*}, so L_k = HH size at t
link_counts <- df_followup %>%
  group_by(uqnr_t) %>%
  summarise(
    L_k          = n(),
    n_stayers    = sum(!is_mover),
    n_movers_in  = sum(is_mover),
    .groups      = "drop"
  )

cat("Distribution of L_k (potential links):\n")
print(summary(link_counts$L_k))
cat("\n")

# --- Per-origin link counts L_{k,l} ---
# How many members in follow-up HH k came from baseline HH l?
L_kl <- df_followup %>%
  group_by(uqnr_t, uqnr) %>%
  summarise(L_kl = n(), .groups = "drop")

# How many baseline HHs does each follow-up HH link to?
multi_origin <- L_kl %>%
  group_by(uqnr_t) %>%
  summarise(n_origins = n(), .groups = "drop")

cat("Follow-up HHs with exactly 1 origin:", sum(multi_origin$n_origins == 1), "\n")
cat("Follow-up HHs with 2+ origins:", sum(multi_origin$n_origins >= 2), "\n\n")

# ==============================================================================
# EXERCISE 4: COMPARE ONE-TO-ONE vs. MANY-TO-MANY CONTINUITY RULES
# → Slide 25 (Q&A), Slide 26 (answer), Slide 37 (code)
# Concept: Falorsi et al. (2025), Section 2.1, Figure 2.1
# ==============================================================================
cat("--- EXERCISE 4: One-to-One vs. Many-to-Many Comparison ---\n\n")

# --- One-to-one: follow head only ---
# The continuation HH is the one where the original head resides
head_hhs <- df_followup %>%
  filter(is_head) %>%
  pull(uqnr_t) %>%
  unique()

n_hh_1to1 <- length(head_hhs)

# Count persons covered under one-to-one
persons_1to1 <- df_followup %>%
  filter(uqnr_t %in% head_hhs) %>%
  nrow()

# --- Many-to-many: all HHs with any link to baseline ---
n_hh_m2m     <- n_distinct(df_followup$uqnr_t)
persons_m2m  <- nrow(df_followup)

# --- Coverage loss ---
persons_lost <- persons_m2m - persons_1to1
pct_loss     <- 100 * persons_lost / persons_m2m

cat("ONE-TO-ONE RULE:\n")
cat("  Continuation HHs:", n_hh_1to1, "\n")
cat("  Persons covered:", persons_1to1, "\n\n")

cat("MANY-TO-MANY RULE:\n")
cat("  Continuation HHs:", n_hh_m2m, "\n")
cat("  Persons covered:", persons_m2m, "\n\n")

cat("COVERAGE COMPARISON:\n")
cat("  Persons lost under 1-to-1:", persons_lost, "\n")
cat("  Coverage loss:", round(pct_loss, 1), "%\n\n")

# ==============================================================================
# EXERCISE 5: MULTIPLICITY FACTOR & TRANSITION MATRIX PREVIEW
# → Slide 28 (multiplicity), Slides 29-32 (gross change), Slide 38 (verify)
# Concept: Falorsi et al. (2025), Eq. (3.14)-(3.15), Section 4.2
# ==============================================================================
cat("--- EXERCISE 5: Multiplicity Factor & Transition Preview ---\n\n")

# Multiplicity factor assignment (assuming two equal-sized original samples)
# Factor = 2 if HH has at least one member from t* who is not a mover
# Factor = 1 otherwise (purely-mover HHs)
multiplicity <- df_followup %>%
  group_by(uqnr_t) %>%
  summarise(
    has_original_member = any(!is_mover),
    L_k = n(),
    .groups = "drop"
  ) %>%
  mutate(
    mult_factor = ifelse(has_original_member, 2L, 1L)
  )

cat("Multiplicity factor distribution:\n")
print(table(Factor = multiplicity$mult_factor))
cat("\n")

cat("Mean L_k by multiplicity factor:\n")
multiplicity %>%
  group_by(mult_factor) %>%
  summarise(mean_Lk = round(mean(L_k), 2), .groups = "drop") %>%
  print()
cat("\n")

# --- Simulate a poverty status transition ---
# Assign baseline poverty status (approx 20% poor, matching SADC norms)
df_followup <- df_followup %>%
  mutate(
    poor_tstar = rbinom(n(), 1, prob = 0.20),
    # At follow-up: 70% of poor stay poor, 5% of non-poor become poor
    poor_t = case_when(
      poor_tstar == 1 ~ rbinom(n(), 1, prob = 0.70),
      poor_tstar == 0 ~ rbinom(n(), 1, prob = 0.05),
      TRUE ~ 0L
    )
  )

# Transition matrix (individual level)
trans_mat <- df_followup %>%
  count(poor_tstar, poor_t) %>%
  mutate(pct = round(100 * n / sum(n), 1))

cat("Poverty Transition Matrix (simulated):\n")
cat(sprintf("  %-30s %10s %10s\n", "", "Poor at t", "Non-poor at t"))
for (g in c(1, 0)) {
  row <- trans_mat %>% filter(poor_tstar == g)
  label <- ifelse(g == 1, "Poor at t*", "Non-poor at t*")
  p_poor <- row %>% filter(poor_t == 1) %>% pull(pct)
  p_npoor <- row %>% filter(poor_t == 0) %>% pull(pct)
  if (length(p_poor) == 0) p_poor <- 0
  if (length(p_npoor) == 0) p_npoor <- 0
  cat(sprintf("  %-30s %9.1f%% %9.1f%%\n", label, p_poor, p_npoor))
}

# Net change in poverty
pov_tstar <- mean(df_followup$poor_tstar)
pov_t     <- mean(df_followup$poor_t)
cat(sprintf("\n  Poverty rate at t*: %.1f%%\n", 100 * pov_tstar))
cat(sprintf("  Poverty rate at t:  %.1f%%\n", 100 * pov_t))
cat(sprintf("  Net change:         %.1f pp\n", 100 * (pov_t - pov_tstar)))
cat("\n")

# ==============================================================================
# VERIFICATION TABLE
# → Slide 38
# ==============================================================================
cat(strrep("=", 70), "\n")
cat("  VERIFICATION TABLE — LAB 5.1 RESULTS\n")
cat(strrep("=", 70), "\n")
cat(sprintf("  %-40s %12s\n", "Metric", "Value"))
cat(strrep("-", 54), "\n")
cat(sprintf("  %-40s %12d\n", "Persons at baseline", N_baseline))
cat(sprintf("  %-40s %12d\n", "HHs at baseline", n_distinct(df$uqnr)))
cat(sprintf("  %-40s %12d\n", "Persons alive at t", N_intersect))
cat(sprintf("  %-40s %12d\n", "Hybrid pop. size", N_hybrid))
cat(sprintf("  %-40s %11.1f%%\n", "Hybrid coverage of U_t",
            100 * N_hybrid / N_Ut))
cat(sprintf("  %-40s %12d\n", "Simulated movers", n_movers))
cat(sprintf("  %-40s %12d\n", "Split-off HHs", n_splitoff_hh))
cat(sprintf("  %-40s %12d\n", "Follow-up HHs (many-to-many)", n_hh_m2m))
cat(sprintf("  %-40s %12d\n", "Continuation HHs (one-to-one)", n_hh_1to1))
cat(sprintf("  %-40s %12d\n", "Persons lost (one-to-one)", persons_lost))
cat(sprintf("  %-40s %11.1f%%\n", "Coverage loss", pct_loss))
cat(sprintf("  %-40s %11.1f%%\n", "Poverty at t*", 100 * pov_tstar))
cat(sprintf("  %-40s %11.1f%%\n", "Poverty at t", 100 * pov_t))
cat(strrep("=", 54), "\n")
cat("  End of Lab 5.1 — Proceed to Module 2 (GWSM Weights)\n\n")
